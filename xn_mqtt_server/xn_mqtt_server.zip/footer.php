    </main>
    <footer class="footer">
        <small>&copy; <?php echo date('Y'); ?> MQTT 管理后台</small>
    </footer>
</div>
</body>
</html>
